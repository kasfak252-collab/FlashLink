# Add project specific ProGuard rules here.
-keep class com.flashlink.app.data.db.entity.** { *; }
-keepattributes *Annotation*
