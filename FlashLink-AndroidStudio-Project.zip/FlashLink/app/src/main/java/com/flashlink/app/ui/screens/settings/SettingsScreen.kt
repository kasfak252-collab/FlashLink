package com.flashlink.app.ui.screens.settings

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.flashlink.app.FlashLinkApp
import com.flashlink.app.data.repository.ThemeMode
import com.flashlink.app.ui.screens.home.formatBytes
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(app: FlashLinkApp) {
    val scope = rememberCoroutineScope()
    val themeMode by app.settingsRepository.themeMode.collectAsState(initial = ThemeMode.SYSTEM)
    val nickname by app.settingsRepository.nickname.collectAsState(initial = null)
    val isPremium by app.settingsRepository.isPremium.collectAsState(initial = false)
    val boosterEnabled by app.settingsRepository.smartSpeedBoosterEnabled.collectAsState(initial = true)
    val autoReconnect by app.settingsRepository.autoReconnectEnabled.collectAsState(initial = true)

    val statsCount by app.transferRepository.observeStatsCount().collectAsState(initial = 0)
    val statsBytes by app.transferRepository.observeStatsTotalBytes().collectAsState(initial = 0L)
    val statsAvgSpeed by app.transferRepository.observeStatsAvgSpeed().collectAsState(initial = 0L)

    var nicknameInput by remember(nickname) { mutableStateOf(nickname ?: "") }

    Scaffold(topBar = { TopAppBar(title = { Text("Settings", fontWeight = FontWeight.Bold) }) }) { padding ->
        Column(
            modifier = Modifier.padding(padding).padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Spacer(Modifier.height(4.dp))

            SettingsSection(title = "Profile") {
                OutlinedTextField(
                    value = nicknameInput,
                    onValueChange = {
                        nicknameInput = it
                        scope.launch { app.settingsRepository.setNickname(it) }
                    },
                    label = { Text("Device nickname") },
                    leadingIcon = { Icon(Icons.Filled.Badge, contentDescription = null) },
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier.fillMaxWidth()
                )
            }

            SettingsSection(title = "Appearance") {
                ThemeMode.entries.forEach { mode ->
                    ListItem(
                        headlineContent = { Text(mode.name.lowercase().replaceFirstChar { it.uppercase() }) },
                        leadingContent = {
                            RadioButton(
                                selected = themeMode == mode,
                                onClick = { scope.launch { app.settingsRepository.setThemeMode(mode) } }
                            )
                        },
                        modifier = Modifier.clip(RoundedCornerShape(12.dp))
                    )
                }
            }

            SettingsSection(title = "Transfer") {
                SwitchRow(
                    title = "Smart Speed Booster",
                    subtitle = "Automatically pick the fastest available connection",
                    checked = boosterEnabled,
                    onCheckedChange = { scope.launch { app.settingsRepository.setSmartSpeedBooster(it) } }
                )
                SwitchRow(
                    title = "Auto-reconnect",
                    subtitle = "Resume transfers automatically if connection drops",
                    checked = autoReconnect,
                    onCheckedChange = { scope.launch { app.settingsRepository.setAutoReconnect(it) } }
                )
            }

            SettingsSection(title = "Premium") {
                ListItem(
                    headlineContent = { Text(if (isPremium) "Premium active — no ads" else "Upgrade to Premium") },
                    supportingContent = { Text("Removes ads and unlocks unlimited large-file transfers") },
                    leadingContent = { Icon(Icons.Filled.WorkspacePremium, contentDescription = null) },
                    trailingContent = {
                        if (!isPremium) {
                            FilledTonalButton(onClick = { scope.launch { app.settingsRepository.setPremium(true) } }) {
                                Text("Upgrade")
                            }
                        }
                    }
                )
            }

            SettingsSection(title = "Transfer statistics") {
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    StatBlock("Total transfers", statsCount.toString(), Modifier.weight(1f))
                    StatBlock("Data moved", formatBytes(statsBytes), Modifier.weight(1f))
                    StatBlock("Avg speed", "${formatBytes(statsAvgSpeed)}/s", Modifier.weight(1f))
                }
            }

            Spacer(Modifier.height(24.dp))
        }
    }
}

@Composable
private fun SettingsSection(title: String, content: @Composable () -> Unit) {
    Column {
        Text(title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
        Spacer(Modifier.height(8.dp))
        ElevatedCard(shape = RoundedCornerShape(18.dp)) {
            Column(Modifier.padding(12.dp)) { content() }
        }
    }
}

@Composable
private fun SwitchRow(title: String, subtitle: String, checked: Boolean, onCheckedChange: (Boolean) -> Unit) {
    ListItem(
        headlineContent = { Text(title) },
        supportingContent = { Text(subtitle) },
        trailingContent = { Switch(checked = checked, onCheckedChange = onCheckedChange) }
    )
}

@Composable
private fun StatBlock(label: String, value: String, modifier: Modifier = Modifier) {
    Column(modifier = modifier) {
        Text(value, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
        Text(label, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}
