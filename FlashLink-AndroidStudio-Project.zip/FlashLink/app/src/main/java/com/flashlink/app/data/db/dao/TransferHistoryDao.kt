package com.flashlink.app.data.db.dao

import androidx.room.*
import com.flashlink.app.data.db.entity.TransferHistoryEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface TransferHistoryDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(entity: TransferHistoryEntity)

    @Query("SELECT * FROM transfer_history ORDER BY completedAtMillis DESC")
    fun observeAll(): Flow<List<TransferHistoryEntity>>

    // Powers the History screen's search + category/direction/status filters
    @Query("""
        SELECT * FROM transfer_history
        WHERE (:query = '' OR fileName LIKE '%' || :query || '%' OR peerName LIKE '%' || :query || '%')
        AND (:category = 'ALL' OR category = :category)
        AND (:direction = 'ALL' OR direction = :direction)
        AND (:status = 'ALL' OR status = :status)
        ORDER BY completedAtMillis DESC
    """)
    fun search(
        query: String,
        category: String,
        direction: String,
        status: String
    ): Flow<List<TransferHistoryEntity>>

    @Query("DELETE FROM transfer_history WHERE id = :id")
    suspend fun deleteById(id: String)

    @Query("DELETE FROM transfer_history")
    suspend fun clearAll()

    // Powers the Transfer Statistics dashboard
    @Query("SELECT COUNT(*) FROM transfer_history WHERE status = 'COMPLETED'")
    fun observeCompletedCount(): Flow<Int>

    @Query("SELECT COALESCE(SUM(sizeBytes),0) FROM transfer_history WHERE status = 'COMPLETED'")
    fun observeTotalBytes(): Flow<Long>

    @Query("SELECT COALESCE(AVG(avgSpeedBytesPerSec),0) FROM transfer_history WHERE status = 'COMPLETED'")
    fun observeAverageSpeed(): Flow<Long>
}
