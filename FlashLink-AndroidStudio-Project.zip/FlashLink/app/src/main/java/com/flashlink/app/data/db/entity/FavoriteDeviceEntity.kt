package com.flashlink.app.data.db.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "favorite_devices")
data class FavoriteDeviceEntity(
    @PrimaryKey val deviceId: String,   // MAC / BT address
    val rawName: String,
    val nickname: String?,
    val avatarUri: String?,
    val transport: String,
    val addedAtMillis: Long
)
