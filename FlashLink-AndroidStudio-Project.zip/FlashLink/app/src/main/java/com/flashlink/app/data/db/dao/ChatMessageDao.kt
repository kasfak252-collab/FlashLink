package com.flashlink.app.data.db.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import com.flashlink.app.data.db.entity.ChatMessageEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface ChatMessageDao {

    @Insert
    suspend fun insert(entity: ChatMessageEntity)

    @Query("SELECT * FROM chat_messages WHERE peerId = :peerId ORDER BY timestampMillis ASC")
    fun observeConversation(peerId: String): Flow<List<ChatMessageEntity>>

    @Query("DELETE FROM chat_messages WHERE peerId = :peerId")
    suspend fun clearConversation(peerId: String)
}
