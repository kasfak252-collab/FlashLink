package com.flashlink.app.core.transfer

import com.flashlink.app.core.security.CryptoUtil
import com.flashlink.app.data.model.TransferItem
import com.flashlink.app.data.model.TransferStatus
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.update
import java.io.*
import java.net.Socket
import javax.crypto.SecretKey
import kotlin.math.roundToLong

/**
 * Transport-agnostic chunked transfer engine. Works identically over a Wi-Fi
 * Direct TCP socket or a Bluetooth RFCOMM socket — both expose InputStream/
 * OutputStream, which is all this class needs. Handles:
 *  - chunking large files (streams, never loads a whole file into memory —
 *    this is what makes 100GB+ files safe to send)
 *  - per-chunk AES-256-GCM encryption
 *  - live speed/ETA/progress reporting via StateFlow
 *  - resume: every chunk ack'd updates `resumeOffset`; if the connection drops,
 *    a new session can call `send(..., resumeFromByte = lastOffset)` and the
 *    reader/writer seek straight to that point instead of restarting.
 */
class TransferEngine {

    companion object {
        const val CHUNK_SIZE = 256 * 1024 // 256KB plaintext chunks before encryption
        private const val PROGRESS_EMIT_INTERVAL_MS = 200L
    }

    private val _activeTransfers = MutableStateFlow<Map<String, TransferItem>>(emptyMap())
    val activeTransfers: StateFlow<Map<String, TransferItem>> = _activeTransfers

    /**
     * Sender side. Streams [file] to [outputStream] in encrypted chunks, starting
     * at [resumeFromByte] (0 for a fresh transfer). Protocol per chunk:
     *   [4 bytes: chunk length][chunk bytes (IV + AES-GCM ciphertext)]
     * A final zero-length chunk marks EOF.
     */
    suspend fun send(
        item: TransferItem,
        file: File,
        outputStream: OutputStream,
        sessionKey: SecretKey,
        resumeFromByte: Long = 0L
    ) {
        updateItem(item.copy(status = TransferStatus.IN_PROGRESS, resumeOffset = resumeFromByte))

        val dataOut = DataOutputStream(BufferedOutputStream(outputStream))
        RandomAccessFile(file, "r").use { raf ->
            raf.seek(resumeFromByte)
            val buffer = ByteArray(CHUNK_SIZE)
            var transferred = resumeFromByte
            var lastEmit = System.currentTimeMillis()
            var lastEmitBytes = transferred
            val startTime = System.currentTimeMillis()

            while (true) {
                val read = raf.read(buffer)
                if (read == -1) break

                val plain = if (read == buffer.size) buffer else buffer.copyOf(read)
                val encrypted = CryptoUtil.encryptChunk(sessionKey, plain)
                dataOut.writeInt(encrypted.size)
                dataOut.write(encrypted)
                dataOut.flush()

                transferred += read

                val now = System.currentTimeMillis()
                if (now - lastEmit >= PROGRESS_EMIT_INTERVAL_MS) {
                    val elapsedSec = (now - lastEmit) / 1000.0
                    val bytesSinceLast = transferred - lastEmitBytes
                    val speed = if (elapsedSec > 0) (bytesSinceLast / elapsedSec).roundToLong() else 0L
                    val remaining = item.sizeBytes - transferred
                    val eta = if (speed > 0) remaining / speed else -1L

                    updateItem(
                        item.copy(
                            status = TransferStatus.IN_PROGRESS,
                            bytesTransferred = transferred,
                            speedBytesPerSec = speed,
                            etaSeconds = eta,
                            resumeOffset = transferred
                        )
                    )
                    lastEmit = now
                    lastEmitBytes = transferred
                }
            }
            // EOF marker
            dataOut.writeInt(0)
            dataOut.flush()

            val totalElapsedSec = (System.currentTimeMillis() - startTime) / 1000.0
            val avgSpeed = if (totalElapsedSec > 0) ((transferred - resumeFromByte) / totalElapsedSec).roundToLong() else 0L
            updateItem(
                item.copy(
                    status = TransferStatus.COMPLETED,
                    bytesTransferred = item.sizeBytes,
                    speedBytesPerSec = avgSpeed,
                    etaSeconds = 0,
                    completedAtMillis = System.currentTimeMillis()
                )
            )
        }
    }

    /**
     * Receiver side. Reads encrypted chunks from [inputStream] and appends them
     * to [destinationFile], starting at [resumeFromByte] so an interrupted
     * receive can continue exactly where it left off rather than re-downloading
     * bytes already safely on disk.
     */
    suspend fun receive(
        item: TransferItem,
        destinationFile: File,
        inputStream: InputStream,
        sessionKey: SecretKey,
        resumeFromByte: Long = 0L
    ) {
        updateItem(item.copy(status = TransferStatus.IN_PROGRESS, resumeOffset = resumeFromByte))

        val dataIn = DataInputStream(BufferedInputStream(inputStream))
        RandomAccessFile(destinationFile, "rw").use { raf ->
            raf.seek(resumeFromByte)
            var transferred = resumeFromByte
            var lastEmit = System.currentTimeMillis()
            var lastEmitBytes = transferred
            val startTime = System.currentTimeMillis()

            while (true) {
                val chunkLen = dataIn.readInt()
                if (chunkLen == 0) break // EOF marker

                val encrypted = ByteArray(chunkLen)
                dataIn.readFully(encrypted)
                val plain = CryptoUtil.decryptChunk(sessionKey, encrypted)
                raf.write(plain)
                transferred += plain.size

                val now = System.currentTimeMillis()
                if (now - lastEmit >= PROGRESS_EMIT_INTERVAL_MS) {
                    val elapsedSec = (now - lastEmit) / 1000.0
                    val bytesSinceLast = transferred - lastEmitBytes
                    val speed = if (elapsedSec > 0) (bytesSinceLast / elapsedSec).roundToLong() else 0L
                    val remaining = item.sizeBytes - transferred
                    val eta = if (speed > 0) remaining / speed else -1L

                    updateItem(
                        item.copy(
                            status = TransferStatus.IN_PROGRESS,
                            bytesTransferred = transferred,
                            speedBytesPerSec = speed,
                            etaSeconds = eta,
                            resumeOffset = transferred
                        )
                    )
                    lastEmit = now
                    lastEmitBytes = transferred
                }
            }

            val totalElapsedSec = (System.currentTimeMillis() - startTime) / 1000.0
            val avgSpeed = if (totalElapsedSec > 0) ((transferred - resumeFromByte) / totalElapsedSec).roundToLong() else 0L
            updateItem(
                item.copy(
                    status = TransferStatus.COMPLETED,
                    bytesTransferred = item.sizeBytes,
                    speedBytesPerSec = avgSpeed,
                    etaSeconds = 0,
                    completedAtMillis = System.currentTimeMillis()
                )
            )
        }
    }

    fun markFailed(item: TransferItem, error: String) {
        updateItem(item.copy(status = TransferStatus.FAILED, errorMessage = error))
    }

    fun markPaused(item: TransferItem) {
        updateItem(item.copy(status = TransferStatus.PAUSED))
    }

    fun cancel(itemId: String) {
        _activeTransfers.update { it - itemId }
    }

    private fun updateItem(item: TransferItem) {
        _activeTransfers.update { it + (item.id to item) }
    }
}
// Note: TransferItem is a `data class` with `var` properties, so the compiler-generated
// .copy(...) used above already produces a new instance with the fields we override.
