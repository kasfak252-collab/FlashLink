package com.flashlink.app.core.security

import java.security.SecureRandom
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.SecretKeySpec
import android.util.Base64

/**
 * Handles per-session AES-256-GCM encryption for FlashLink's file transfer socket.
 * Each pairing (QR or discovery handshake) negotiates a fresh session key, so
 * every transfer is encrypted end-to-end over Wi-Fi Direct or Bluetooth even
 * though neither transport requires internet.
 */
object CryptoUtil {
    private const val ALGO = "AES/GCM/NoPadding"
    private const val KEY_SIZE = 256
    private const val GCM_TAG_LENGTH_BITS = 128
    private const val IV_LENGTH_BYTES = 12

    fun generateSessionKey(): SecretKey {
        val generator = KeyGenerator.getInstance("AES")
        generator.init(KEY_SIZE, SecureRandom())
        return generator.generateKey()
    }

    fun keyToBase64(key: SecretKey): String = Base64.encodeToString(key.encoded, Base64.NO_WRAP)

    fun keyFromBase64(encoded: String): SecretKey {
        val bytes = Base64.decode(encoded, Base64.NO_WRAP)
        return SecretKeySpec(bytes, "AES")
    }

    /** Encrypts a chunk, prefixing the random IV so the receiver can decrypt independently. */
    fun encryptChunk(key: SecretKey, plain: ByteArray): ByteArray {
        val iv = ByteArray(IV_LENGTH_BYTES).also { SecureRandom().nextBytes(it) }
        val cipher = Cipher.getInstance(ALGO)
        cipher.init(Cipher.ENCRYPT_MODE, key, GCMParameterSpec(GCM_TAG_LENGTH_BITS, iv))
        val encrypted = cipher.doFinal(plain)
        return iv + encrypted
    }

    fun decryptChunk(key: SecretKey, ivAndCipherText: ByteArray): ByteArray {
        val iv = ivAndCipherText.copyOfRange(0, IV_LENGTH_BYTES)
        val cipherText = ivAndCipherText.copyOfRange(IV_LENGTH_BYTES, ivAndCipherText.size)
        val cipher = Cipher.getInstance(ALGO)
        cipher.init(Cipher.DECRYPT_MODE, key, GCMParameterSpec(GCM_TAG_LENGTH_BITS, iv))
        return cipher.doFinal(cipherText)
    }
}
