package com.flashlink.app.ui.screens.transfer

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.flashlink.app.FlashLinkApp
import com.flashlink.app.data.model.TransferItem
import com.flashlink.app.data.model.TransferStatus
import com.flashlink.app.ui.screens.home.formatBytes

@Composable
fun TransferProgressScreen(app: FlashLinkApp) {
    val active by app.transferEngine.activeTransfers.collectAsState()

    Scaffold(topBar = { TopAppBar(title = { Text("Active Transfers", fontWeight = FontWeight.Bold) }) }) { padding ->
        if (active.isEmpty()) {
            Box(Modifier.padding(padding).fillMaxSize(), contentAlignment = androidx.compose.ui.Alignment.Center) {
                Text("Nothing transferring right now", color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        } else {
            LazyColumn(
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp),
                modifier = Modifier.padding(padding)
            ) {
                items(active.values.toList()) { item -> TransferRow(item) }
            }
        }
    }
}

@Composable
private fun TransferRow(item: TransferItem) {
    val progress = if (item.sizeBytes > 0) (item.bytesTransferred.toFloat() / item.sizeBytes.toFloat()).coerceIn(0f, 1f) else 0f

    ElevatedCard(shape = RoundedCornerShape(18.dp)) {
        Column(Modifier.padding(16.dp)) {
            Row(verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                Icon(statusIcon(item.status), contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                Spacer(Modifier.width(10.dp))
                Column(Modifier.weight(1f)) {
                    Text(item.fileName, fontWeight = FontWeight.SemiBold, maxLines = 1)
                    Text(
                        "${item.peerName} · ${formatBytes(item.bytesTransferred)} / ${formatBytes(item.sizeBytes)}",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
            Spacer(Modifier.height(10.dp))
            LinearProgressIndicator(
                progress = { progress },
                modifier = Modifier.fillMaxWidth().height(8.dp).clip(RoundedCornerShape(4.dp))
            )
            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                Text("${formatBytes(item.speedBytesPerSec)}/s", style = MaterialTheme.typography.labelLarge)
                Text(etaLabel(item.etaSeconds), style = MaterialTheme.typography.labelLarge)
                Text("${(progress * 100).toInt()}%", style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.Bold)
            }
        }
    }
}

private fun statusIcon(status: TransferStatus) = when (status) {
    TransferStatus.IN_PROGRESS -> Icons.Filled.SwapVert
    TransferStatus.PAUSED -> Icons.Filled.PauseCircle
    TransferStatus.COMPLETED -> Icons.Filled.CheckCircle
    TransferStatus.FAILED -> Icons.Filled.ErrorOutline
    TransferStatus.CANCELLED -> Icons.Filled.Cancel
    else -> Icons.Filled.HourglassEmpty
}

private fun etaLabel(etaSeconds: Long): String {
    if (etaSeconds < 0) return "--"
    if (etaSeconds == 0L) return "Done"
    val m = etaSeconds / 60
    val s = etaSeconds % 60
    return if (m > 0) "${m}m ${s}s left" else "${s}s left"
}
