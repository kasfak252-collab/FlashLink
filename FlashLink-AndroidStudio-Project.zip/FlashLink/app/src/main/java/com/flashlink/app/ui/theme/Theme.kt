package com.flashlink.app.ui.theme

import android.app.Activity
import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat

private val DarkColors = darkColorScheme(
    primary = FlashBlue,
    onPrimary = FlashWhite,
    secondary = FlashCyanAccent,
    onSecondary = FlashBlack,
    tertiary = FlashBlueLight,
    background = FlashBlack,
    onBackground = FlashTextPrimaryDark,
    surface = FlashCharcoal,
    onSurface = FlashTextPrimaryDark,
    surfaceVariant = FlashCharcoalElevated,
    onSurfaceVariant = FlashTextSecondaryDark,
    error = FlashError
)

private val LightColors = lightColorScheme(
    primary = FlashBlueDark,
    onPrimary = FlashWhite,
    secondary = FlashBlue,
    onSecondary = FlashWhite,
    tertiary = FlashBlueLight,
    background = FlashGreyLight,
    onBackground = FlashTextPrimaryLight,
    surface = FlashGreySurface,
    onSurface = FlashTextPrimaryLight,
    surfaceVariant = FlashGreyLight,
    onSurfaceVariant = FlashTextSecondaryLight,
    error = FlashError
)

@Composable
fun FlashLinkTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) DarkColors else LightColors
    val view = LocalView.current

    if (!view.isInEditMode) {
        SideEffect {
            val window = (view.context as Activity).window
            window.statusBarColor = colorScheme.background.toArgb()
            WindowCompat.getInsetsController(window, view).isAppearanceLightStatusBars = !darkTheme
        }
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = FlashTypography,
        shapes = FlashShapes,
        content = content
    )
}
