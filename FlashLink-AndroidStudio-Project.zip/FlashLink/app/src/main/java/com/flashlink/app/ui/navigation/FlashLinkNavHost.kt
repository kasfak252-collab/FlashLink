package com.flashlink.app.ui.navigation

import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.navigation.NavDestination.Companion.hierarchy
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.flashlink.app.FlashLinkApp
import com.flashlink.app.ui.screens.chat.NearbyChatScreen
import com.flashlink.app.ui.screens.discovery.DiscoveryScreen
import com.flashlink.app.ui.screens.filemanager.FileManagerScreen
import com.flashlink.app.ui.screens.history.HistoryScreen
import com.flashlink.app.ui.screens.home.HomeScreen
import com.flashlink.app.ui.screens.qr.QrPairingScreen
import com.flashlink.app.ui.screens.settings.SettingsScreen

sealed class FlashDestination(val route: String, val label: String, val icon: androidx.compose.ui.graphics.vector.ImageVector) {
    data object Home : FlashDestination("home", "Home", Icons.Filled.Home)
    data object Discovery : FlashDestination("discovery", "Nearby", Icons.Filled.Wifi)
    data object Files : FlashDestination("files", "Files", Icons.Filled.Folder)
    data object History : FlashDestination("history", "History", Icons.Filled.History)
    data object Settings : FlashDestination("settings", "Settings", Icons.Filled.Settings)
}

private val bottomItems = listOf(
    FlashDestination.Home,
    FlashDestination.Discovery,
    FlashDestination.Files,
    FlashDestination.History,
    FlashDestination.Settings
)

@Composable
fun FlashLinkNavHost(app: FlashLinkApp) {
    val navController = rememberNavController()

    Scaffold(
        bottomBar = {
            val backStackEntry by navController.currentBackStackEntryAsState()
            val currentDestination = backStackEntry?.destination

            NavigationBar {
                bottomItems.forEach { dest ->
                    val selected = currentDestination?.hierarchy?.any { it.route == dest.route } == true
                    NavigationBarItem(
                        selected = selected,
                        onClick = {
                            navController.navigate(dest.route) {
                                popUpTo(navController.graph.findStartDestination().id) { saveState = true }
                                launchSingleTop = true
                                restoreState = true
                            }
                        },
                        icon = { Icon(dest.icon, contentDescription = dest.label) },
                        label = { Text(dest.label) }
                    )
                }
            }
        }
    ) { padding ->
        NavHost(
            navController = navController,
            startDestination = FlashDestination.Home.route,
            modifier = androidx.compose.ui.Modifier.padding(padding)
        ) {
            composable(FlashDestination.Home.route) {
                HomeScreen(
                    app = app,
                    onSendClick = { navController.navigate(FlashDestination.Discovery.route) },
                    onQrClick = { navController.navigate("qr_pairing") },
                    onChatClick = { peerId, peerName ->
                        navController.navigate("chat/$peerId/$peerName")
                    }
                )
            }
            composable(FlashDestination.Discovery.route) {
                DiscoveryScreen(app = app)
            }
            composable(FlashDestination.Files.route) {
                FileManagerScreen(app = app)
            }
            composable(FlashDestination.History.route) {
                HistoryScreen(app = app)
            }
            composable(FlashDestination.Settings.route) {
                SettingsScreen(app = app)
            }
            composable("qr_pairing") {
                QrPairingScreen(app = app, onBack = { navController.popBackStack() })
            }
            composable("chat/{peerId}/{peerName}") { backStackEntry ->
                val peerId = backStackEntry.arguments?.getString("peerId") ?: ""
                val peerName = backStackEntry.arguments?.getString("peerName") ?: "Device"
                NearbyChatScreen(app = app, peerId = peerId, peerName = peerName, onBack = { navController.popBackStack() })
            }
        }
    }
}
