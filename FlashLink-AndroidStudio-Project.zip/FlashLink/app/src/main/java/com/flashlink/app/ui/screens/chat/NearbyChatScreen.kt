package com.flashlink.app.ui.screens.chat

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Send
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.flashlink.app.FlashLinkApp
import com.flashlink.app.data.model.ChatMessage
import kotlinx.coroutines.launch
import java.util.UUID

/**
 * Offline nearby-chat: text messages ride over the same encrypted Wi-Fi
 * Direct / Bluetooth socket used for files, so no internet or SMS is needed.
 * Also doubles as the offline clipboard-sharing surface — a "Paste & Send"
 * action here pushes the device clipboard contents as a chat message.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun NearbyChatScreen(app: FlashLinkApp, peerId: String, peerName: String, onBack: () -> Unit) {
    val scope = rememberCoroutineScope()
    val messages by app.transferRepository.observeChat(peerId).collectAsState(initial = emptyList())
    var draft by remember { mutableStateOf("") }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(peerName, fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onBack) { Icon(Icons.Filled.ArrowBack, contentDescription = "Back") }
                }
            )
        },
        bottomBar = {
            Row(
                modifier = Modifier.padding(12.dp).fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                OutlinedTextField(
                    value = draft,
                    onValueChange = { draft = it },
                    placeholder = { Text("Message (sent offline, no internet)") },
                    shape = RoundedCornerShape(20.dp),
                    modifier = Modifier.weight(1f)
                )
                Spacer(Modifier.width(8.dp))
                FilledIconButton(onClick = {
                    if (draft.isNotBlank()) {
                        scope.launch {
                            app.transferRepository.sendChatMessage(
                                ChatMessage(
                                    id = UUID.randomUUID().toString(),
                                    peerId = peerId,
                                    peerName = peerName,
                                    text = draft.trim(),
                                    isMine = true,
                                    timestampMillis = System.currentTimeMillis()
                                )
                            )
                            // TODO: also push this string over the active socket to the peer
                            // via the same encrypted channel TransferEngine uses for files.
                        }
                        draft = ""
                    }
                }) {
                    Icon(Icons.Filled.Send, contentDescription = "Send")
                }
            }
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier.padding(padding).padding(horizontal = 12.dp).fillMaxSize(),
            reverseLayout = true,
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            items(messages.reversed()) { msg ->
                ChatBubble(msg.text, msg.isMine)
            }
        }
    }
}

@Composable
private fun ChatBubble(text: String, isMine: Boolean) {
    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = if (isMine) Arrangement.End else Arrangement.Start) {
        Surface(
            shape = RoundedCornerShape(
                topStart = 18.dp, topEnd = 18.dp,
                bottomStart = if (isMine) 18.dp else 4.dp,
                bottomEnd = if (isMine) 4.dp else 18.dp
            ),
            color = if (isMine) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant,
            modifier = Modifier.padding(vertical = 2.dp)
        ) {
            Text(
                text,
                modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp),
                color = if (isMine) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}
