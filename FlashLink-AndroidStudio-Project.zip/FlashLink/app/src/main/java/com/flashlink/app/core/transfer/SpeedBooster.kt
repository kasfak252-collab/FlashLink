package com.flashlink.app.core.transfer

import com.flashlink.app.data.model.PeerDevice
import com.flashlink.app.data.model.TransportType

/**
 * Decides which transport to use for a given peer/file combo.
 * Rule of thumb encoded here:
 *  - If the peer supports Wi-Fi Direct and it's currently available, always prefer it —
 *    it's roughly 20-100x faster than classic Bluetooth in practice.
 *  - Fall back to Bluetooth only if Wi-Fi Direct connection fails, is unsupported by the
 *    peer's hardware, or Wi-Fi is disabled by device policy.
 *  - For very small files (e.g. a single small doc under ~2MB) Bluetooth's faster
 *    connection-setup time can occasionally win overall, so we allow that override.
 */
object SpeedBooster {

    private const val SMALL_FILE_THRESHOLD_BYTES = 2L * 1024 * 1024

    fun choose(
        peer: PeerDevice,
        wifiDirectAvailable: Boolean,
        totalPayloadBytes: Long,
        boosterEnabled: Boolean
    ): TransportType {
        if (!boosterEnabled) return peer.transport // respect manual choice if user disabled auto mode

        val peerSupportsWifiDirect = peer.transport == TransportType.WIFI_DIRECT
        return when {
            peerSupportsWifiDirect && wifiDirectAvailable && totalPayloadBytes > SMALL_FILE_THRESHOLD_BYTES ->
                TransportType.WIFI_DIRECT
            peerSupportsWifiDirect && wifiDirectAvailable ->
                TransportType.WIFI_DIRECT // still prefer WFD even for small files if it's already connected
            else -> TransportType.BLUETOOTH
        }
    }
}
