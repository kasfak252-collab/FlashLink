package com.flashlink.app.data.repository

import android.content.Context
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.dataStore by preferencesDataStore(name = "flashlink_settings")

/** Theme mode choice; SYSTEM follows the OS setting. */
enum class ThemeMode { LIGHT, DARK, SYSTEM }

class SettingsRepository(private val context: Context) {

    private object Keys {
        val THEME_MODE = stringPreferencesKey("theme_mode")
        val NICKNAME = stringPreferencesKey("device_nickname")
        val AVATAR_URI = stringPreferencesKey("device_avatar_uri")
        val IS_PREMIUM = booleanPreferencesKey("is_premium")
        val SMART_SPEED_BOOSTER = booleanPreferencesKey("smart_speed_booster")
        val AUTO_RECONNECT = booleanPreferencesKey("auto_reconnect")
    }

    val themeMode: Flow<ThemeMode> = context.dataStore.data.map {
        ThemeMode.valueOf(it[Keys.THEME_MODE] ?: ThemeMode.SYSTEM.name)
    }
    suspend fun setThemeMode(mode: ThemeMode) {
        context.dataStore.edit { it[Keys.THEME_MODE] = mode.name }
    }

    val nickname: Flow<String?> = context.dataStore.data.map { it[Keys.NICKNAME] }
    suspend fun setNickname(name: String) {
        context.dataStore.edit { it[Keys.NICKNAME] = name }
    }

    val avatarUri: Flow<String?> = context.dataStore.data.map { it[Keys.AVATAR_URI] }
    suspend fun setAvatarUri(uri: String) {
        context.dataStore.edit { it[Keys.AVATAR_URI] = uri }
    }

    val isPremium: Flow<Boolean> = context.dataStore.data.map { it[Keys.IS_PREMIUM] ?: false }
    suspend fun setPremium(value: Boolean) {
        context.dataStore.edit { it[Keys.IS_PREMIUM] = value }
    }

    val smartSpeedBoosterEnabled: Flow<Boolean> = context.dataStore.data.map { it[Keys.SMART_SPEED_BOOSTER] ?: true }
    suspend fun setSmartSpeedBooster(value: Boolean) {
        context.dataStore.edit { it[Keys.SMART_SPEED_BOOSTER] = value }
    }

    val autoReconnectEnabled: Flow<Boolean> = context.dataStore.data.map { it[Keys.AUTO_RECONNECT] ?: true }
    suspend fun setAutoReconnect(value: Boolean) {
        context.dataStore.edit { it[Keys.AUTO_RECONNECT] = value }
    }
}
