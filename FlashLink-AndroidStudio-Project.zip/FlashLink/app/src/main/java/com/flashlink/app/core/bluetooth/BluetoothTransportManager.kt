package com.flashlink.app.core.bluetooth

import android.annotation.SuppressLint
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothServerSocket
import android.bluetooth.BluetoothSocket
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import com.flashlink.app.data.model.PeerDevice
import com.flashlink.app.data.model.TransportType
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import java.util.UUID

/**
 * Fallback transport used automatically when Wi-Fi Direct is unavailable
 * (peer lacks P2P hardware, or Wi-Fi is disabled by policy). Classic Bluetooth
 * RFCOMM is slower (~1-3 Mbps) but works almost universally on Android 8+.
 */
class BluetoothTransportManager(private val context: Context) {

    companion object {
        // Fixed app UUID — both sides must agree on this to open the RFCOMM channel.
        val FLASHLINK_UUID: UUID = UUID.fromString("8ce255c0-200a-11e0-ac64-0800200c9a66")
        const val SERVICE_NAME = "FlashLinkTransfer"
    }

    private val adapter: BluetoothAdapter? = BluetoothAdapter.getDefaultAdapter()

    private val _pairedDevices = MutableStateFlow<List<PeerDevice>>(emptyList())
    val pairedDevices: StateFlow<List<PeerDevice>> = _pairedDevices

    private val _discoveredDevices = MutableStateFlow<List<PeerDevice>>(emptyList())
    val discoveredDevices: StateFlow<List<PeerDevice>> = _discoveredDevices

    private val discoveryReceiver = object : BroadcastReceiver() {
        @SuppressLint("MissingPermission")
        override fun onReceive(ctx: Context, intent: Intent) {
            if (intent.action == BluetoothDevice.ACTION_FOUND) {
                val device: BluetoothDevice? = intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE)
                device ?: return
                val peer = device.toPeerDevice()
                _discoveredDevices.value = (_discoveredDevices.value + peer).distinctBy { it.id }
            }
        }
    }

    fun isBluetoothSupported(): Boolean = adapter != null
    fun isEnabled(): Boolean = adapter?.isEnabled == true

    fun registerDiscoveryReceiver() {
        context.registerReceiver(discoveryReceiver, IntentFilter(BluetoothDevice.ACTION_FOUND))
    }

    fun unregisterDiscoveryReceiver() {
        runCatching { context.unregisterReceiver(discoveryReceiver) }
    }

    @SuppressLint("MissingPermission")
    fun loadPairedDevices() {
        _pairedDevices.value = adapter?.bondedDevices.orEmpty().map { it.toPeerDevice() }
    }

    @SuppressLint("MissingPermission")
    fun startDiscovery() {
        adapter?.startDiscovery()
    }

    @SuppressLint("MissingPermission")
    fun stopDiscovery() {
        adapter?.cancelDiscovery()
    }

    /** Host side: opens a listening RFCOMM socket, blocks until a peer connects. */
    @SuppressLint("MissingPermission")
    fun listenForConnection(): BluetoothSocket? {
        val serverSocket: BluetoothServerSocket =
            adapter?.listenUsingRfcommWithServiceRecord(SERVICE_NAME, FLASHLINK_UUID) ?: return null
        return try {
            serverSocket.accept()
        } finally {
            runCatching { serverSocket.close() }
        }
    }

    /** Client side: connects directly to a known/paired device. */
    @SuppressLint("MissingPermission")
    fun connectTo(device: BluetoothDevice): BluetoothSocket {
        stopDiscovery() // discovery slows down connection attempts
        val socket = device.createRfcommSocketToServiceRecord(FLASHLINK_UUID)
        socket.connect()
        return socket
    }

    @SuppressLint("MissingPermission")
    private fun BluetoothDevice.toPeerDevice() = PeerDevice(
        id = address,
        name = name ?: address,
        transport = TransportType.BLUETOOTH,
        signalLevel = 2 // classic BT doesn't expose RSSI without extra scans; shown as "fair" by default
    )
}
