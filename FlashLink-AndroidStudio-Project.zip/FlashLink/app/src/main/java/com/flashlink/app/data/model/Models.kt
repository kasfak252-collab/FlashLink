package com.flashlink.app.data.model

/** Transport used for a given transfer/connection. SpeedBooster picks between these. */
enum class TransportType { WIFI_DIRECT, BLUETOOTH }

enum class FileCategory { PHOTO, VIDEO, MUSIC, DOCUMENT, APK, ZIP, FOLDER, OTHER }

enum class TransferDirection { SEND, RECEIVE }

enum class TransferStatus { QUEUED, CONNECTING, IN_PROGRESS, PAUSED, COMPLETED, FAILED, CANCELLED }

data class PeerDevice(
    val id: String,               // MAC address or BT address
    val name: String,             // raw device name broadcast over the wire
    val nickname: String? = null, // user-assigned nickname, overrides name in UI
    val avatarUri: String? = null,
    val transport: TransportType,
    val isFavorite: Boolean = false,
    val signalLevel: Int = 0,     // 0-4 bars, derived from RSSI / P2P group info
    val lastSeenMillis: Long = System.currentTimeMillis()
)

/** A single file/folder queued for transfer, tracked live in memory + persisted to Room on completion. */
data class TransferItem(
    val id: String,
    val fileName: String,
    val filePath: String,
    val sizeBytes: Long,
    val category: FileCategory,
    val direction: TransferDirection,
    val peerName: String,
    val peerId: String,
    val transport: TransportType,
    var status: TransferStatus = TransferStatus.QUEUED,
    var bytesTransferred: Long = 0L,
    var speedBytesPerSec: Long = 0L,
    var etaSeconds: Long = -1L,
    var startedAtMillis: Long = 0L,
    var completedAtMillis: Long = 0L,
    var resumeOffset: Long = 0L,   // last confirmed byte offset, for auto-resume
    var errorMessage: String? = null
)

data class ChatMessage(
    val id: String,
    val peerId: String,
    val peerName: String,
    val text: String,
    val isMine: Boolean,
    val timestampMillis: Long
)
