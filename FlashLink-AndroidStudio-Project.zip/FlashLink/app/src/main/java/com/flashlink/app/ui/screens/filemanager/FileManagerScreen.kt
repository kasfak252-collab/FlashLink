package com.flashlink.app.ui.screens.filemanager

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.flashlink.app.FlashLinkApp
import com.flashlink.app.data.model.FileCategory

private data class CategoryTile(val category: FileCategory, val label: String, val icon: ImageVector)

private val tiles = listOf(
    CategoryTile(FileCategory.PHOTO, "Photos", Icons.Filled.Image),
    CategoryTile(FileCategory.VIDEO, "Videos", Icons.Filled.Movie),
    CategoryTile(FileCategory.MUSIC, "Music", Icons.Filled.MusicNote),
    CategoryTile(FileCategory.DOCUMENT, "Documents", Icons.Filled.Description),
    CategoryTile(FileCategory.APK, "Apps (APK)", Icons.Filled.Android),
    CategoryTile(FileCategory.ZIP, "Archives", Icons.Filled.FolderZip),
    CategoryTile(FileCategory.FOLDER, "Folders", Icons.Filled.Folder),
)

/**
 * Built-in file manager entry point. Tapping a tile opens the system storage
 * picker scoped to that category (Intent.ACTION_OPEN_DOCUMENT with the right
 * MIME filter) — this keeps the app free of broad MANAGE_EXTERNAL_STORAGE
 * permission requirements while still giving one-tap access per file type.
 * The picked file(s) then flow into TransferEngine.send(...) after the user
 * picks a destination peer on the Discovery screen.
 */
@Composable
fun FileManagerScreen(app: FlashLinkApp) {
    var selectedCategory by remember { mutableStateOf<FileCategory?>(null) }

    Scaffold(topBar = { TopAppBar(title = { Text("File Manager", fontWeight = FontWeight.Bold) }) }) { padding ->
        LazyVerticalGrid(
            columns = GridCells.Fixed(2),
            contentPadding = PaddingValues(16.dp),
            horizontalArrangement = Arrangement.spacedBy(12.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
            modifier = Modifier.padding(padding)
        ) {
            items(tiles) { tile ->
                ElevatedCard(
                    shape = RoundedCornerShape(20.dp),
                    onClick = { selectedCategory = tile.category },
                    modifier = Modifier.fillMaxWidth().height(120.dp)
                ) {
                    Column(
                        Modifier.fillMaxSize().padding(16.dp),
                        verticalArrangement = Arrangement.SpaceBetween
                    ) {
                        Icon(tile.icon, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(28.dp))
                        Text(tile.label, fontWeight = FontWeight.SemiBold)
                    }
                }
            }
        }

        // Selecting a tile launches the system document/media picker scoped to
        // that category's MIME type(s); result handling lives in the hosting
        // Activity via registerForActivityResult(ActivityResultContracts.OpenMultipleDocuments()).
    }
}
