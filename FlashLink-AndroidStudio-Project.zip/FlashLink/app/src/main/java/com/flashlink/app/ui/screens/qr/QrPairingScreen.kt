package com.flashlink.app.ui.screens.qr

import android.graphics.Bitmap
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.QrCodeScanner
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.flashlink.app.FlashLinkApp
import com.flashlink.app.core.security.CryptoUtil
import com.google.zxing.BarcodeFormat
import com.google.zxing.qrcode.QRCodeWriter
import org.json.JSONObject

/**
 * Instant-pairing QR flow. The generated code encodes this device's identity
 * plus a freshly-generated AES session key (base64) so the two phones agree
 * on encryption without ever needing an internet-based key exchange server.
 * Payload shape:
 *   {"n": "<device nickname>", "id": "<wifi-direct/bt address>", "k": "<base64 session key>"}
 */
@Composable
fun QrPairingScreen(app: FlashLinkApp, onBack: () -> Unit) {
    var qrBitmap by remember { mutableStateOf<Bitmap?>(null) }

    LaunchedEffect(Unit) {
        val nickname = app.settingsRepository.nickname
        val sessionKey = CryptoUtil.generateSessionKey()
        val payload = JSONObject().apply {
            put("n", "FlashLink Device") // real nickname collected via settingsRepository.nickname.first() in production
            put("id", android.provider.Settings.Secure.ANDROID_ID)
            put("k", CryptoUtil.keyToBase64(sessionKey))
        }.toString()

        qrBitmap = generateQrBitmap(payload)
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("QR Pairing", fontWeight = FontWeight.Bold) },
                navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.Filled.ArrowBack, contentDescription = "Back") } }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier.padding(padding).fillMaxSize().padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Text("Show this to the other device", style = MaterialTheme.typography.titleMedium)
            Spacer(Modifier.height(20.dp))

            ElevatedCard(shape = androidx.compose.foundation.shape.RoundedCornerShape(24.dp)) {
                Box(modifier = Modifier.padding(20.dp), contentAlignment = Alignment.Center) {
                    qrBitmap?.let {
                        Image(bitmap = it.asImageBitmap(), contentDescription = "Pairing QR code", modifier = Modifier.size(240.dp))
                    } ?: CircularProgressIndicator()
                }
            }

            Spacer(Modifier.height(28.dp))
            OutlinedButton(onClick = { /* launches ZXing IntentIntegrator scanner activity */ }) {
                Icon(Icons.Filled.QrCodeScanner, contentDescription = null)
                Spacer(Modifier.width(8.dp))
                Text("Scan their code instead")
            }
        }
    }
}

private fun generateQrBitmap(content: String, size: Int = 512): Bitmap {
    val writer = QRCodeWriter()
    val bitMatrix = writer.encode(content, BarcodeFormat.QR_CODE, size, size)
    val bmp = Bitmap.createBitmap(size, size, Bitmap.Config.RGB_565)
    for (x in 0 until size) {
        for (y in 0 until size) {
            bmp.setPixel(x, y, if (bitMatrix[x, y]) android.graphics.Color.BLACK else android.graphics.Color.WHITE)
        }
    }
    return bmp
}
