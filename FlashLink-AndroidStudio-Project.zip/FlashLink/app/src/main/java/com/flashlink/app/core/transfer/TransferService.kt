package com.flashlink.app.core.transfer

import android.app.*
import android.content.Intent
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import com.flashlink.app.MainActivity
import com.flashlink.app.R

/**
 * Foreground service that owns the live transfer notification (progress %,
 * speed, ETA) and keeps the process — and the Wi-Fi Direct / Bluetooth
 * sockets — alive while the screen is off or the app is backgrounded.
 * Also the natural place to hook WorkManager-driven auto-reconnect: if the
 * socket drops mid-transfer, this service schedules a reconnect attempt and
 * resumes from TransferItem.resumeOffset once the link is back.
 */
class TransferService : Service() {

    companion object {
        const val CHANNEL_ID = "flashlink_transfers"
        const val NOTIFICATION_ID = 1001

        const val ACTION_UPDATE = "com.flashlink.app.action.UPDATE_PROGRESS"
        const val EXTRA_TITLE = "extra_title"
        const val EXTRA_PROGRESS = "extra_progress"
        const val EXTRA_SPEED_LABEL = "extra_speed_label"
    }

    override fun onCreate() {
        super.onCreate()
        createChannelIfNeeded()
        startForeground(NOTIFICATION_ID, buildNotification("Waiting for transfer…", 0, ""))
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_UPDATE) {
            val title = intent.getStringExtra(EXTRA_TITLE) ?: "Transferring…"
            val progress = intent.getIntExtra(EXTRA_PROGRESS, 0)
            val speed = intent.getStringExtra(EXTRA_SPEED_LABEL) ?: ""
            val nm = getSystemService(NotificationManager::class.java)
            nm.notify(NOTIFICATION_ID, buildNotification(title, progress, speed))
        }
        return START_STICKY
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private fun buildNotification(title: String, progress: Int, speedLabel: String): Notification {
        val openAppIntent = Intent(this, MainActivity::class.java)
        val pendingIntent = PendingIntent.getActivity(
            this, 0, openAppIntent,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle(title)
            .setContentText(if (speedLabel.isNotEmpty()) speedLabel else "$progress%")
            .setSmallIcon(R.drawable.ic_notification_bolt)
            .setProgress(100, progress, false)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setContentIntent(pendingIntent)
            .build()
    }

    private fun createChannelIfNeeded() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "File Transfers",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Shows ongoing FlashLink transfer progress"
            }
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }
}
