package com.flashlink.app.core.wifidirect

import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.net.wifi.p2p.WifiP2pConfig
import android.net.wifi.p2p.WifiP2pDevice
import android.net.wifi.p2p.WifiP2pManager
import android.net.wifi.p2p.WifiP2pManager.Channel
import com.flashlink.app.data.model.PeerDevice
import com.flashlink.app.data.model.TransportType
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.callbackFlow

/**
 * Wraps Android's WifiP2pManager (Wi-Fi Direct) for peer discovery and group formation.
 * This is FlashLink's primary, fastest transport — typically 40-250 Mbps depending on
 * hardware, vs. ~1-3 Mbps over classic Bluetooth. SpeedBooster prefers this whenever
 * a P2P-capable peer is found; Bluetooth is only used as fallback.
 *
 * The transfer socket itself (TCP over the P2P group's local IP range, port GROUP_PORT)
 * is implemented in TransferEngine — this class only owns discovery + connection setup.
 */
class WifiDirectManager(
    private val context: Context,
    private val manager: WifiP2pManager = context.getSystemService(Context.WIFI_P2P_SERVICE) as WifiP2pManager
) {
    companion object {
        const val GROUP_OWNER_PORT = 8988
    }

    private val channel: Channel = manager.initialize(context, context.mainLooper, null)

    private val _peers = MutableStateFlow<List<PeerDevice>>(emptyList())
    val peers: StateFlow<List<PeerDevice>> = _peers

    private val _isGroupOwner = MutableStateFlow(false)
    val isGroupOwner: StateFlow<Boolean> = _isGroupOwner

    private val _groupOwnerAddress = MutableStateFlow<String?>(null)
    val groupOwnerAddress: StateFlow<String?> = _groupOwnerAddress

    private val intentFilter = IntentFilter().apply {
        addAction(WifiP2pManager.WIFI_P2P_STATE_CHANGED_ACTION)
        addAction(WifiP2pManager.WIFI_P2P_PEERS_CHANGED_ACTION)
        addAction(WifiP2pManager.WIFI_P2P_CONNECTION_CHANGED_ACTION)
        addAction(WifiP2pManager.WIFI_P2P_THIS_DEVICE_CHANGED_ACTION)
    }

    private val receiver = WifiDirectBroadcastReceiver(
        manager = manager,
        channel = channel,
        onPeersChanged = { peerList ->
            _peers.value = peerList.deviceList.map { it.toPeerDevice() }
        },
        onConnectionChanged = { info ->
            _isGroupOwner.value = info.isGroupOwner
            _groupOwnerAddress.value = info.groupOwnerAddress?.hostAddress
        }
    )

    fun register() {
        context.registerReceiver(receiver, intentFilter)
    }

    fun unregister() {
        runCatching { context.unregisterReceiver(receiver) }
    }

    @SuppressLint("MissingPermission")
    fun startDiscovery(onResult: (Boolean) -> Unit = {}) {
        manager.discoverPeers(channel, object : WifiP2pManager.ActionListener {
            override fun onSuccess() = onResult(true)
            override fun onFailure(reason: Int) = onResult(false)
        })
    }

    fun stopDiscovery() {
        manager.stopPeerDiscovery(channel, null)
    }

    @SuppressLint("MissingPermission")
    fun connect(device: WifiP2pDevice, onResult: (Boolean) -> Unit = {}) {
        val config = WifiP2pConfig().apply {
            deviceAddress = device.deviceAddress
            wps.setup = android.net.wifi.WpsInfo.PBC
        }
        manager.connect(channel, config, object : WifiP2pManager.ActionListener {
            override fun onSuccess() = onResult(true)
            override fun onFailure(reason: Int) = onResult(false)
        })
    }

    fun disconnect() {
        manager.removeGroup(channel, null)
    }

    @SuppressLint("MissingPermission")
    private fun WifiP2pDevice.toPeerDevice() = PeerDevice(
        id = deviceAddress,
        name = deviceName ?: "Unknown device",
        transport = TransportType.WIFI_DIRECT,
        signalLevel = when (status) {
            WifiP2pDevice.CONNECTED -> 4
            WifiP2pDevice.AVAILABLE -> 3
            else -> 1
        }
    )
}
