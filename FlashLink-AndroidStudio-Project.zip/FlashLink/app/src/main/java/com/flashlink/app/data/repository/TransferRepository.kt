package com.flashlink.app.data.repository

import com.flashlink.app.data.db.dao.ChatMessageDao
import com.flashlink.app.data.db.dao.FavoriteDeviceDao
import com.flashlink.app.data.db.dao.TransferHistoryDao
import com.flashlink.app.data.db.entity.ChatMessageEntity
import com.flashlink.app.data.db.entity.FavoriteDeviceEntity
import com.flashlink.app.data.db.entity.TransferHistoryEntity
import com.flashlink.app.data.model.*
import kotlinx.coroutines.flow.Flow

/**
 * Single source of truth for anything persisted: completed transfer history,
 * favorite devices, and nearby-chat conversation logs.
 * Live in-progress transfer state (speed/ETA/progress) is held separately in
 * TransferEngine's own StateFlow, since that updates many times/sec and
 * shouldn't hit the DB until a transfer finishes.
 */
class TransferRepository(
    private val historyDao: TransferHistoryDao,
    private val favoriteDao: FavoriteDeviceDao,
    private val chatDao: ChatMessageDao
) {
    fun observeHistory(
        query: String = "",
        category: FileCategory? = null,
        direction: TransferDirection? = null,
        status: TransferStatus? = null
    ): Flow<List<TransferHistoryEntity>> = historyDao.search(
        query = query,
        category = category?.name ?: "ALL",
        direction = direction?.name ?: "ALL",
        status = status?.name ?: "ALL"
    )

    suspend fun recordCompletedTransfer(item: TransferItem) {
        historyDao.insert(
            TransferHistoryEntity(
                id = item.id,
                fileName = item.fileName,
                filePath = item.filePath,
                sizeBytes = item.sizeBytes,
                category = item.category.name,
                direction = item.direction.name,
                peerName = item.peerName,
                peerId = item.peerId,
                transport = item.transport.name,
                status = item.status.name,
                avgSpeedBytesPerSec = item.speedBytesPerSec,
                startedAtMillis = item.startedAtMillis,
                completedAtMillis = item.completedAtMillis,
                errorMessage = item.errorMessage
            )
        )
    }

    suspend fun clearHistory() = historyDao.clearAll()
    suspend fun deleteHistoryItem(id: String) = historyDao.deleteById(id)

    fun observeStatsCount() = historyDao.observeCompletedCount()
    fun observeStatsTotalBytes() = historyDao.observeTotalBytes()
    fun observeStatsAvgSpeed() = historyDao.observeAverageSpeed()

    fun observeFavorites(): Flow<List<FavoriteDeviceEntity>> = favoriteDao.observeAll()

    suspend fun addFavorite(device: PeerDevice) = favoriteDao.upsert(
        FavoriteDeviceEntity(
            deviceId = device.id,
            rawName = device.name,
            nickname = device.nickname,
            avatarUri = device.avatarUri,
            transport = device.transport.name,
            addedAtMillis = System.currentTimeMillis()
        )
    )

    suspend fun removeFavorite(deviceId: String) = favoriteDao.remove(deviceId)
    suspend fun isFavorite(deviceId: String) = favoriteDao.isFavorite(deviceId)
    suspend fun renameDevice(deviceId: String, nickname: String?, avatarUri: String?) =
        favoriteDao.updateNicknameAndAvatar(deviceId, nickname, avatarUri)

    fun observeChat(peerId: String): Flow<List<ChatMessageEntity>> = chatDao.observeConversation(peerId)

    suspend fun sendChatMessage(msg: ChatMessage) = chatDao.insert(
        ChatMessageEntity(
            id = msg.id,
            peerId = msg.peerId,
            peerName = msg.peerName,
            text = msg.text,
            isMine = msg.isMine,
            timestampMillis = msg.timestampMillis
        )
    )
}
