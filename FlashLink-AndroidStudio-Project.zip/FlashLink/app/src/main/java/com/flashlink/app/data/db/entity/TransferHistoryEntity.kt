package com.flashlink.app.data.db.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "transfer_history")
data class TransferHistoryEntity(
    @PrimaryKey val id: String,
    val fileName: String,
    val filePath: String,
    val sizeBytes: Long,
    val category: String,          // FileCategory.name
    val direction: String,         // TransferDirection.name
    val peerName: String,
    val peerId: String,
    val transport: String,         // TransportType.name
    val status: String,            // TransferStatus.name
    val avgSpeedBytesPerSec: Long,
    val startedAtMillis: Long,
    val completedAtMillis: Long,
    val errorMessage: String? = null
)
