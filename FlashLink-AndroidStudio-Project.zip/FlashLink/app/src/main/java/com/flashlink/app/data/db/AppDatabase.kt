package com.flashlink.app.data.db

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.flashlink.app.data.db.dao.ChatMessageDao
import com.flashlink.app.data.db.dao.FavoriteDeviceDao
import com.flashlink.app.data.db.dao.TransferHistoryDao
import com.flashlink.app.data.db.entity.ChatMessageEntity
import com.flashlink.app.data.db.entity.FavoriteDeviceEntity
import com.flashlink.app.data.db.entity.TransferHistoryEntity

@Database(
    entities = [TransferHistoryEntity::class, FavoriteDeviceEntity::class, ChatMessageEntity::class],
    version = 1,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun transferHistoryDao(): TransferHistoryDao
    abstract fun favoriteDeviceDao(): FavoriteDeviceDao
    abstract fun chatMessageDao(): ChatMessageDao

    companion object {
        @Volatile private var INSTANCE: AppDatabase? = null

        fun getInstance(context: Context): AppDatabase =
            INSTANCE ?: synchronized(this) {
                INSTANCE ?: Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "flashlink.db"
                ).fallbackToDestructiveMigration()
                    .build().also { INSTANCE = it }
            }
    }
}
