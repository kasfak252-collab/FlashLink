package com.flashlink.app.ui.screens.discovery

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.flashlink.app.FlashLinkApp
import com.flashlink.app.data.model.PeerDevice
import com.flashlink.app.data.model.TransportType
import kotlinx.coroutines.launch

/**
 * One-tap discovery screen: starts Wi-Fi Direct + Bluetooth scanning together,
 * merges results into a single list, and shows which transport each peer will
 * use (SpeedBooster's choice is surfaced directly in the row).
 *
 * Note: this screen assumes runtime permissions (location for Wi-Fi P2P/BLE,
 * nearby-devices for Bluetooth on API 31+) have already been granted via the
 * Accompanist permissions flow wired in at the navigation entry point.
 */
@Composable
fun DiscoveryScreen(app: FlashLinkApp) {
    val scope = rememberCoroutineScope()
    val wifiPeers by app.wifiDirectManager.peers.collectAsState()
    val btPaired by app.bluetoothManager.pairedDevices.collectAsState()
    val btDiscovered by app.bluetoothManager.discoveredDevices.collectAsState()
    var isScanning by remember { mutableStateOf(false) }

    val allPeers = remember(wifiPeers, btPaired, btDiscovered) {
        (wifiPeers + btPaired + btDiscovered).distinctBy { it.id }
    }

    DisposableEffect(Unit) {
        app.wifiDirectManager.register()
        app.bluetoothManager.registerDiscoveryReceiver()
        app.bluetoothManager.loadPairedDevices()
        onDispose {
            app.wifiDirectManager.unregister()
            app.bluetoothManager.unregisterDiscoveryReceiver()
        }
    }

    Scaffold(
        topBar = { TopAppBar(title = { Text("Nearby Devices", fontWeight = FontWeight.Bold) }) },
        floatingActionButton = {
            ExtendedFloatingActionButton(
                onClick = {
                    isScanning = true
                    app.wifiDirectManager.startDiscovery { }
                    app.bluetoothManager.startDiscovery()
                    scope.launch {
                        kotlinx.coroutines.delay(12_000)
                        isScanning = false
                    }
                },
                icon = {
                    if (isScanning) {
                        CircularProgressIndicator(modifier = Modifier.size(18.dp), strokeWidth = 2.dp)
                    } else {
                        Icon(Icons.Filled.Radar, contentDescription = null)
                    }
                },
                text = { Text(if (isScanning) "Scanning…" else "Scan Nearby") }
            )
        }
    ) { padding ->
        if (allPeers.isEmpty()) {
            Box(modifier = Modifier.padding(padding).fillMaxSize(), contentAlignment = Alignment.Center) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(
                        Icons.Filled.WifiFind,
                        contentDescription = null,
                        modifier = Modifier.size(56.dp),
                        tint = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(Modifier.height(12.dp))
                    Text("No devices found yet", color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Text("Tap Scan Nearby to look for devices", color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodyMedium)
                }
            }
        } else {
            LazyColumn(
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp),
                modifier = Modifier.padding(padding)
            ) {
                items(allPeers) { peer ->
                    PeerRow(
                        peer = peer,
                        onConnect = { /* Hands off to WifiDirectManager.connect(...) or BluetoothTransportManager.connectTo(...)
                                        based on peer.transport, then opens the file picker (see FileManagerScreen). */ },
                        onFavoriteToggle = { scope.launch { app.transferRepository.addFavorite(peer) } }
                    )
                }
            }
        }
    }
}

@Composable
private fun PeerRow(peer: PeerDevice, onConnect: () -> Unit, onFavoriteToggle: () -> Unit) {
    ElevatedCard(shape = RoundedCornerShape(18.dp), modifier = Modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = if (peer.transport == TransportType.WIFI_DIRECT) Icons.Filled.Wifi else Icons.Filled.Bluetooth,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.primary,
                modifier = Modifier.size(30.dp)
            )
            Spacer(Modifier.width(14.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(peer.nickname ?: peer.name, fontWeight = FontWeight.SemiBold)
                Text(
                    if (peer.transport == TransportType.WIFI_DIRECT) "Wi-Fi Direct · Fast" else "Bluetooth · Fallback",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            IconButton(onClick = onFavoriteToggle) {
                Icon(Icons.Filled.StarBorder, contentDescription = "Add to favorites")
            }
            FilledTonalButton(onClick = onConnect, shape = RoundedCornerShape(14.dp)) {
                Text("Connect")
            }
        }
    }
}
