package com.flashlink.app.ui.screens.history

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.flashlink.app.FlashLinkApp
import com.flashlink.app.data.db.entity.TransferHistoryEntity
import com.flashlink.app.data.model.FileCategory
import com.flashlink.app.data.model.TransferDirection
import com.flashlink.app.ui.screens.home.formatBytes
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HistoryScreen(app: FlashLinkApp) {
    var query by remember { mutableStateOf("") }
    var categoryFilter by remember { mutableStateOf<FileCategory?>(null) }
    var directionFilter by remember { mutableStateOf<TransferDirection?>(null) }
    val scope = rememberCoroutineScope()

    val history by app.transferRepository.observeHistory(
        query = query,
        category = categoryFilter,
        direction = directionFilter
    ).collectAsState(initial = emptyList())

    Scaffold(
        topBar = { TopAppBar(title = { Text("Transfer History", fontWeight = FontWeight.Bold) }) }
    ) { padding ->
        Column(Modifier.padding(padding).padding(horizontal = 16.dp)) {
            OutlinedTextField(
                value = query,
                onValueChange = { query = it },
                placeholder = { Text("Search file or device name") },
                leadingIcon = { Icon(Icons.Filled.Search, contentDescription = null) },
                singleLine = true,
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier.fillMaxWidth().padding(top = 8.dp, bottom = 10.dp)
            )

            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                item {
                    FilterChip(
                        selected = directionFilter == TransferDirection.RECEIVE,
                        onClick = { directionFilter = if (directionFilter == TransferDirection.RECEIVE) null else TransferDirection.RECEIVE },
                        label = { Text("Received") }
                    )
                }
                item {
                    FilterChip(
                        selected = directionFilter == TransferDirection.SEND,
                        onClick = { directionFilter = if (directionFilter == TransferDirection.SEND) null else TransferDirection.SEND },
                        label = { Text("Sent") }
                    )
                }
                items(FileCategory.entries.toTypedArray()) { cat ->
                    FilterChip(
                        selected = categoryFilter == cat,
                        onClick = { categoryFilter = if (categoryFilter == cat) null else cat },
                        label = { Text(cat.name.lowercase().replaceFirstChar { it.uppercase() }) }
                    )
                }
            }

            Spacer(Modifier.height(10.dp))

            if (history.isEmpty()) {
                Box(Modifier.fillMaxSize(), contentAlignment = androidx.compose.ui.Alignment.Center) {
                    Text("No transfers match your filters", color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            } else {
                LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp), contentPadding = PaddingValues(bottom = 16.dp)) {
                    items(history, key = { it.id }) { entry ->
                        HistoryRow(entry, onDelete = { scope.launch { app.transferRepository.deleteHistoryItem(entry.id) } })
                    }
                }
            }
        }
    }
}

@Composable
private fun HistoryRow(entry: TransferHistoryEntity, onDelete: () -> Unit) {
    ElevatedCard(shape = RoundedCornerShape(16.dp)) {
        Row(
            Modifier.fillMaxWidth().padding(14.dp),
            verticalAlignment = androidx.compose.ui.Alignment.CenterVertically
        ) {
            Icon(
                if (entry.direction == TransferDirection.SEND.name) Icons.Filled.Upload else Icons.Filled.Download,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.primary
            )
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(entry.fileName, fontWeight = FontWeight.SemiBold, maxLines = 1)
                Text(
                    "${entry.peerName} · ${formatBytes(entry.sizeBytes)} · ${entry.status.lowercase()}",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            IconButton(onClick = onDelete) {
                Icon(Icons.Filled.DeleteOutline, contentDescription = "Delete")
            }
        }
    }
}
