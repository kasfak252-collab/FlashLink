package com.flashlink.app.data.db.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "chat_messages")
data class ChatMessageEntity(
    @PrimaryKey val id: String,
    val peerId: String,
    val peerName: String,
    val text: String,
    val isMine: Boolean,
    val timestampMillis: Long
)
