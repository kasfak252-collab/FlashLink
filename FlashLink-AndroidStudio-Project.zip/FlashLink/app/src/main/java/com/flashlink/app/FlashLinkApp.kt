package com.flashlink.app

import android.app.Application
import com.flashlink.app.core.bluetooth.BluetoothTransportManager
import com.flashlink.app.core.transfer.TransferEngine
import com.flashlink.app.core.wifidirect.WifiDirectManager
import com.flashlink.app.data.db.AppDatabase
import com.flashlink.app.data.repository.SettingsRepository
import com.flashlink.app.data.repository.TransferRepository

/**
 * Simple manual DI container (no Hilt/Koin dependency needed). Everything here
 * is a lightweight, process-lifetime singleton — appropriate for a small app
 * like this; swap for Hilt if the codebase grows much larger.
 */
class FlashLinkApp : Application() {

    lateinit var database: AppDatabase
        private set
    lateinit var transferRepository: TransferRepository
        private set
    lateinit var settingsRepository: SettingsRepository
        private set
    lateinit var wifiDirectManager: WifiDirectManager
        private set
    lateinit var bluetoothManager: BluetoothTransportManager
        private set
    val transferEngine: TransferEngine = TransferEngine()

    override fun onCreate() {
        super.onCreate()
        database = AppDatabase.getInstance(this)
        transferRepository = TransferRepository(
            historyDao = database.transferHistoryDao(),
            favoriteDao = database.favoriteDeviceDao(),
            chatDao = database.chatMessageDao()
        )
        settingsRepository = SettingsRepository(this)
        wifiDirectManager = WifiDirectManager(this)
        bluetoothManager = BluetoothTransportManager(this)
    }
}
