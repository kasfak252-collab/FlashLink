package com.flashlink.app.data.db.dao

import androidx.room.*
import com.flashlink.app.data.db.entity.FavoriteDeviceEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface FavoriteDeviceDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(entity: FavoriteDeviceEntity)

    @Query("DELETE FROM favorite_devices WHERE deviceId = :deviceId")
    suspend fun remove(deviceId: String)

    @Query("SELECT * FROM favorite_devices ORDER BY nickname, rawName")
    fun observeAll(): Flow<List<FavoriteDeviceEntity>>

    @Query("SELECT EXISTS(SELECT 1 FROM favorite_devices WHERE deviceId = :deviceId)")
    suspend fun isFavorite(deviceId: String): Boolean

    @Query("UPDATE favorite_devices SET nickname = :nickname, avatarUri = :avatarUri WHERE deviceId = :deviceId")
    suspend fun updateNicknameAndAvatar(deviceId: String, nickname: String?, avatarUri: String?)
}
