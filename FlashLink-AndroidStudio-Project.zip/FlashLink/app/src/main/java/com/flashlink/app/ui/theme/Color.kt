package com.flashlink.app.ui.theme

import androidx.compose.ui.graphics.Color

// Core brand palette — premium blue & black
val FlashBlue = Color(0xFF2979FF)       // primary electric blue
val FlashBlueDark = Color(0xFF0D47A1)   // deep blue
val FlashBlueLight = Color(0xFF82B1FF)  // light accent blue
val FlashCyanAccent = Color(0xFF00E5FF) // speed/energy accent

val FlashBlack = Color(0xFF0A0E14)      // near-black background
val FlashCharcoal = Color(0xFF141A24)   // card surface (dark)
val FlashCharcoalElevated = Color(0xFF1C2330)

val FlashWhite = Color(0xFFF5F7FA)
val FlashGreyLight = Color(0xFFECEFF4)  // light surface
val FlashGreySurface = Color(0xFFFFFFFF)

val FlashSuccess = Color(0xFF00E676)
val FlashWarning = Color(0xFFFFC107)
val FlashError = Color(0xFFFF5252)

val FlashTextPrimaryDark = Color(0xFFF2F5FA)
val FlashTextSecondaryDark = Color(0xFF9AA5B4)
val FlashTextPrimaryLight = Color(0xFF12151C)
val FlashTextSecondaryLight = Color(0xFF5C6472)
